# simple-crud-django
Simple CRUD con django, utilizando vistas basadas en funciones y autentificacion 


1. Crear entorno virtual `virtualenv nombre-entorno`
2. Instalar dependecias: `pip install -r requierements.txt`
3. Realizar migraciones `python manage.py makemigrations && python manage.py migrate`
4. Correr servidor `python manage.py runserver`
