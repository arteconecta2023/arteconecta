package com.arteconecta.io;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
